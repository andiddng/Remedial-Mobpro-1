package org.d3if4003.hitungbmimodul5.ui

import androidx.fragment.app.Fragment
import org.d3if4003.hitungbmimodul5.R

class AboutFragment: Fragment(R.layout.fragment_about)