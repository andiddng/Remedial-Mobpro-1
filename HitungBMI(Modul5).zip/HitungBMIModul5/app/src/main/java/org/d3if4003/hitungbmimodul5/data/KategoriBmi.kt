package org.d3if4003.hitungbmimodul5.data

enum class KategoriBmi {KURUS, IDEAL, GEMUK}