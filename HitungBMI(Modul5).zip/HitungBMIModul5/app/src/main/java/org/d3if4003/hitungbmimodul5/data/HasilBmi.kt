package org.d3if4003.hitungbmimodul5.data

data class HasilBmi(
    val bmi: Float,
    val kategori: KategoriBmi )
