package org.d3if4003.galerihewan2

data class Hewan(
    val nama : String,
    val namaLatin : String,
    val imageResId : Int
)
