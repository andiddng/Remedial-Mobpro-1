package org.d3if4003.galerihewan2.hewan

import org.d3if4003.galerihewan2.R

data class Hewan(
    val nama : String,
    val namaLatin : String,
    val imageId: String
)
