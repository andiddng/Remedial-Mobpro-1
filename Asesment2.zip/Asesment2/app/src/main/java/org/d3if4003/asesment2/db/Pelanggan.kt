package org.d3if4003.asesment2.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tabel_data_pelanggan")
data class Pelanggan(

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id_pelanggan")
    val id: Int,

    @ColumnInfo(name = "nama_pelanggan")
    var name: String,

    @ColumnInfo(name = "email_pelanggan")
    var email: String
)