package org.d3if4003.asesment2.db


import androidx.room.*

@Dao
interface PelangganDao {
    @Insert
    suspend fun insertPelanggan(pelanggan: Pelanggan): Long

    @Update
    suspend fun updatePelanggan(pelanggan: Pelanggan) : Int

    @Delete
    suspend fun deletPelanggan(pelanggan: Pelanggan) : Int

    @Query("DELETE FROM tabel_data_pelanggan")
    suspend fun deletAll() : Int

    @Query("SELECT * FROM tabel_data_pelanggan")
    fun getAllPelanggan(): kotlinx.coroutines.flow.Flow<List<Pelanggan>>
}