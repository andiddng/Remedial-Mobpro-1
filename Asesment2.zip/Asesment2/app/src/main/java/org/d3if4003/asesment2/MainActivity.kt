package org.d3if4003.asesment2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import org.d3if4003.asesment2.databinding.ActivityMainBinding
import org.d3if4003.asesment2.db.Pelanggan
import org.d3if4003.asesment2.db.PelangganDatabase
import org.d3if4003.asesment2.db.PelangganRepo

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var pelangganViewModel: PelangganViewModel
    private lateinit var adapter: MyRecyclerViewAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        val dao = PelangganDatabase.getInstance(application).pelangganDao
        val repository = PelangganRepo(dao)
        val factory = PelangganViewodelFactory(repository)
        pelangganViewModel = ViewModelProvider(this, factory).get(PelangganViewModel::class.java)
        binding.myViewModel = pelangganViewModel
        binding.lifecycleOwner = this

        pelangganViewModel.message.observe(this, Observer {
            it.getContentIfNotHandled()?.let {
                Toast.makeText(this, it, Toast.LENGTH_LONG).show()
            }
        })

        initRecyclerView()
    }

    private fun initRecyclerView() {
        binding.pelangganRecycleview.layoutManager = LinearLayoutManager(this)
        adapter = MyRecyclerViewAdapter({ selectedItem: Pelanggan -> listItemClicked(selectedItem) })
        binding.pelangganRecycleview.adapter = adapter
        displaySubscribersList()
    }

    private fun displaySubscribersList() {
        pelangganViewModel.getSavedPelanggan().observe(this, Observer {
            adapter.setList(it)
            adapter.notifyDataSetChanged()
        })
    }

    private fun listItemClicked(pelanggan: Pelanggan) {
        pelangganViewModel.initUpdateAndDelete(pelanggan)
    }
}