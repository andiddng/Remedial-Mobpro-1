package org.d3if4003.asesment2

import android.util.Patterns
import androidx.lifecycle.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.collect
import org.d3if4003.asesment2.db.PelangganRepo
import org.d3if4003.asesment2.db.Pelanggan

class PelangganViewModel(private val repository: PelangganRepo) : ViewModel(){
    private var isUpdateOrDelete = false
    private lateinit var pelangganToUpdateOrDelete: Pelanggan

    val inputNama = MutableLiveData<String>()
    val inputEmail = MutableLiveData<String>()
    val saveUpdate = MutableLiveData<String>()
    val delete = MutableLiveData<String>()

    private val statusMessage = MutableLiveData<Event<String>>()
    val message: LiveData<Event<String>>
        get() = statusMessage

    init {
        saveUpdate.value = "Save"
        delete.value = "Clear All"
    }

    fun initUpdateAndDelete(pelanggan: Pelanggan) {
        inputNama.value = pelanggan.name
        inputEmail.value = pelanggan.email
        isUpdateOrDelete = true
        pelangganToUpdateOrDelete = pelanggan
        saveUpdate.value = "Update"
        delete.value = "Delete"
    }

    fun saveOrUpdate() {
        if (inputNama.value == null) {
            statusMessage.value = Event("Masukkan nama pelanggan")
        } else if (inputEmail.value == null) {
            statusMessage.value = Event("Masukkan email pelanggan")
        } else if (!Patterns.EMAIL_ADDRESS.matcher(inputEmail.value!!).matches()) {
            statusMessage.value = Event("Masukkan email yang benar")
        } else {
            if (isUpdateOrDelete) {
                pelangganToUpdateOrDelete.name = inputNama.value!!
                pelangganToUpdateOrDelete.email = inputEmail.value!!
                updatePelanggan(pelangganToUpdateOrDelete)
            } else {
                val name = inputNama.value!!
                val email = inputEmail.value!!
                insertPelanggan(Pelanggan(0, name, email))
                inputNama.value = ""
                inputEmail.value = ""
            }
        }
    }

    private fun insertPelanggan(pelanggan: Pelanggan) = viewModelScope.launch {
        val newRowId = repository.insert(pelanggan)
        if (newRowId.toString().compareTo(Int.toString(),true) > -1) {
            statusMessage.value = Event("Pelanggan berhasil ditambahkan $newRowId")
        } else {
            statusMessage.value = Event("Error Occurred")
        }
    }


    private fun updatePelanggan(pelanggan: Pelanggan) = viewModelScope.launch {
        val noOfRows = repository.update(pelanggan)
        if (noOfRows.toString().compareTo(Int.toString(),true) > 0) {
            inputNama.value = ""
            inputEmail.value = ""
            isUpdateOrDelete = false
            saveUpdate.value = "Save"
            delete.value = "Clear All"
            statusMessage.value = Event("$noOfRows Data berhasil diperbarui")
        } else {
            statusMessage.value = Event("Error Occurred")
        }
    }

    fun getSavedPelanggan() = liveData {
        repository.pelanggan.collect {
            emit(it)
        }
    }

    fun clearAllOrDelete() {
        if (isUpdateOrDelete) {
            deletePelanggan(pelangganToUpdateOrDelete)
        } else {
            clearAll()
        }
    }

    private fun deletePelanggan(pelanggan: Pelanggan) = viewModelScope.launch {
        val noOfRowsDeleted = repository.delete(pelanggan)
        if (noOfRowsDeleted.toString().compareTo(Int.toString(),true)> 0) {
            inputNama.value = ""
            inputEmail.value = ""
            isUpdateOrDelete = false
            saveUpdate.value = "Save"
            delete.value = "Clear All"
            statusMessage.value = Event("$noOfRowsDeleted Data berhasil dihapus")
        } else {
            statusMessage.value = Event("Error Occurred")
        }
    }

    private fun clearAll() = viewModelScope.launch {
        val noOfRowsDeleted = repository.deleteAll()
        if (noOfRowsDeleted.toString().compareTo(Int.toString(),true)> 0) {
            statusMessage.value = Event("$noOfRowsDeleted Pelanggan berhasil dihapus")
        } else {
            statusMessage.value = Event("Error Occurred")
        }
    }
}