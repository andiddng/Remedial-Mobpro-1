package org.d3if4003.asesment2.db

class PelangganRepo(private val dao:PelangganDao) {
    val pelanggan = dao.getAllPelanggan()

    suspend fun insert(pelanggan: Pelanggan){
        dao.insertPelanggan(pelanggan)
    }
    suspend fun update(pelanggan: Pelanggan){
        dao.updatePelanggan(pelanggan)
    }
    suspend fun delete(pelanggan: Pelanggan){
        dao.deletPelanggan(pelanggan)
    }
    suspend fun deleteAll(){
        dao.deletAll()
    }
}