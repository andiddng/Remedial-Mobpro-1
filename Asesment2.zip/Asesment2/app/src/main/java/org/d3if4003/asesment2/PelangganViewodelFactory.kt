package org.d3if4003.asesment2

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import org.d3if4003.asesment2.db.PelangganRepo

class PelangganViewodelFactory(private val repository:PelangganRepo)
    :ViewModelProvider.Factory{
    override fun <T : ViewModel?> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PelangganViewModel::class.java)){
            return PelangganViewModel(repository) as T
        }
        throw IllegalArgumentException("Viewmodel tidak diketahui")
    }

}