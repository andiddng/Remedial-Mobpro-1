package org.d3if4003.asesment2.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Pelanggan::class], version = 1)
abstract class PelangganDatabase : RoomDatabase() {
    abstract val pelangganDao: PelangganDao

    companion object {
        @Volatile
        private var INSTANCE: PelangganDatabase? = null
        fun getInstance(context: Context): PelangganDatabase {
            synchronized(this) {
                var instance = INSTANCE
                if (instance == null) {
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        PelangganDatabase::class.java,
                        "tabel_data_pelanngan"
                    ).build()
                }
                return instance
            }
        }
    }
}